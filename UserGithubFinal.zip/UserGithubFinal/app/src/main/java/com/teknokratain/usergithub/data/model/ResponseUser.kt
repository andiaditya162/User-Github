package com.teknokratain.usergithub.data.model

data class ResponseUser(
    val items : ArrayList<User>
)
